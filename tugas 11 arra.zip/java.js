// Ambil elemen gambar dan audio
const hewanAudio = document.getElementById("hewanAudio");

// Ambil semua gambar dengan class 'hewanImage'
const hewanImages = document.querySelectorAll(".hewanImage");

// Tambahkan event listener untuk klik pada gambar
hewanImages.forEach(function (image) {
  image.addEventListener("click", function () {
    // Ambil URL suara dari atribut data-sound pada gambar
    const soundUrl = image.getAttribute("data-sound");
    hewanAudio.src = soundUrl; // Ubah sumber suara
    hewanAudio.play(); // Putar suara
  });
});
